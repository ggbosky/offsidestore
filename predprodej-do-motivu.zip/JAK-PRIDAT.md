# Předprodej — přidání do tvého motivu

Tohle **není nový motiv**. Je to pět souborů, které vložíš do toho svého.
Nepřijdeš tím o žádné nastavení, co máš naklikané v editoru.

Všechno se dělá v: **Internetový obchod → Motivy → ⋯ u tvého motivu → Upravit kód**

---

## 1. Nová sekce

V levém sloupci najdi složku **sections** → **Přidat novou sekci** →
pojmenuj ji `offside-predprodej` → smaž, co ti tam Shopify předvyplní →
vlož celý obsah souboru `sections/offside-predprodej.liquid` → **Uložit**.

## 2. Obrázek pásu

Složka **assets** → **Přidat novou položku** → **Nahrát soubor** →
vyber `assets/os-predprodej-pas.webp` → nahraj.

Musí se jmenovat přesně takhle, sekce si ho hledá podle názvu.

## 3. Styly

Složka **assets** → klikni na `offside.css` → označ celý obsah (Ctrl+A),
smaž a vlož obsah souboru `assets/offside.css` → **Uložit**.

> Tenhle soubor obsahuje i všechny dosavadní styly, takže se nic neztratí.
> Přibyly jen styly pro předprodej.

## 4. Zařazení na úvodní stránku

**Motivy → Přizpůsobit** → domovská stránka → **Přidat sekci** →
**Offside — Předprodej** → přetáhni ji myší **hned pod Hero**.

Chceš ji **místo** hera? Klikni na Hero a dole dej **Skrýt sekci**.
Smazat ji nemusíš, kdyžtak ji zase zapneš.

### Co v ní nastavíš

| Volba | K čemu |
| --- | --- |
| Kam vede proklik | Kolekce s předprodejem. Platí pro pás i tlačítko. |
| Grafika | Vlastní obrázek pásu. Prázdné = ten přiložený. |
| Konec předprodeje | `2026-12-10`. Odpočet se dopočítá sám. |
| Na velkých obrazovkách text skrýt | Zapnuto. Na počítači to samé říká pás, na telefonu je v něm písmo malé, tak tam text zůstává. |

---

## 5. Nepovinné: vlastní vzhled kolekce

Když chceš, aby stránka s čepicemi měla nahoře taky ten pás:

1. **sections** → `offside-kolekce.liquid` → nahraď obsahem ze stejného
   souboru v balíčku (přibyla jen kotva, aby šlo z pásu odskočit na zboží)
2. **templates** → **Přidat novou šablonu** → typ **collection** →
   název `predprodej` → vlož obsah `templates/collection.predprodej.json`
3. **Produkty → Kolekce** → tvoje kolekce s čepicemi → vpravo dole
   **Šablona motivu** → vyber `collection.predprodej`

---

## Na co si dát pozor

**Grafika pásu je široká 1024 px.** Přes celou šířku webu se roztáhne,
takže na velkém monitoru bude trochu měkká. Když ji máš i ve větším
rozlišení (ideálně 2400 px na šířku), nahraj ji v sekci do pole *Grafika* —
přiložený soubor se pak nepoužije.

**Ceny v obrázku.** Pás i jednotlivé vizuály mají cenu vypálenou v grafice.
Až budeš zakládat produkty v Shopify, nahraj k nim **fotky bez ceny**,
jinak se cena na stránce kolekce ukáže dvakrát — jednou v obrázku a jednou
pod ním.

**Termín.** Po 10. 12. 2026 se místo odpočtu objeví „Předprodej skončil".
Sekci pak buď skryj, nebo přepiš datum na další akci.
